/*
  CONTROL DE ACTIVOS - LABORATORIO DE ELECTRONICA  (v4 - COMPLETO)
  Hardware: ESP32 + lector RFID RC522 (LEDs externos opcionales).

  NOVEDADES v4
   - Alta remota: registrar equipos/tarjetas desde la pestaña "Altas" del panel web.
   - Autorizacion de prestamo desde la ventana flotante del panel (tiempo + confirmacion).
   - El limite autorizado se guarda en la etiqueta, en el registro y en el evento "prestamo".

  CONEXIONES RC522 -> ESP32 (todo a 3.3 V, NUNCA a 5 V):
   SDA(SS) -> GPIO5   SCK -> GPIO18   MOSI -> GPIO23   MISO -> GPIO19
   RST     -> GPIO27  IRQ -> (sin conectar)   3.3V -> 3V3   GND -> GND
  LEDs opcionales: GPIO25 (verde) y GPIO26 (rojo), cada uno con resistencia 220 ohm a GND.

  COMANDOS (Monitor Serie 115200, "Nueva linea"):
   U 2 JUAN0001        graba tarjeta de USUARIO nivel 2
   A 3 OSC00001 120    graba ACTIVO nivel requerido 3, limite 120 min (opcional)
   INV / FIN           inicia / termina inventario
   INC D | INC I       proximo equipo con incidencia (D=danado, I=incompleto)
   LIST | HORA | HELP

  Librerias: MFRC522 (miguelbalboa). Placa: "ESP32 Dev Module".
*/

#include <SPI.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <Preferences.h>
#include <MFRC522.h>
#include <mbedtls/md.h>
#include <time.h>

// ================== TUS DATOS (EDITA ESTO) ==================

#define WIFI_SSID  "TU_WIFI"
#define WIFI_PASS  "TU_CLAVE_WIFI"

// URL base del proyecto (SIN /rest/v1)
#define SUPA_URL   "https://ixpofphqqdczidykjnau.supabase.co"
#define SUPA_KEY   "PEGA_AQUI_TU_ANON_KEY"
#define DEVICE_ID  "lab-electronica-01"

// Clave secreta de firma HMAC (16 bytes).
// OJO: si la cambias, las etiquetas ya grabadas dejan de ser validas.
static const uint8_t HMAC_KEY[16] = {0x4C,0x61,0x62,0x45,0x6C,0x65,0x63,0x31,
                                     0x39,0x7A,0x51,0x2B,0x88,0xA3,0x5E,0xD4};

// ================== CONFIGURACION ==================
#define USE_EXT_LEDS 0          // 1 = usa LEDs externos en GPIO25/26
#define PIN_LED_OK   25
#define PIN_LED_ERR  26

const uint8_t  ADMIN_LEVEL        = 4;
const uint16_t DEFAULT_LIMIT_MIN  = 120;
const uint16_t MAX_USES           = 100;
const bool     BLOCK_ON_OVERDUE   = true;
const bool     REQUIRE_WEB_CONFIRM = true;   // true = el prestamo exige autorizar en la web
const unsigned long SESSION_MS    = 60000;   // igual a PREST_VENTANA del panel
const long     GMT_OFFSET_SEC     = -4 * 3600;   // Bolivia UTC-4

// Horario por dia (0=Dom ... 6=Sab), minutos desde 00:00.
const uint16_t OPEN_MIN[7]  = {0, 420, 420, 420, 420, 420, 480};
const uint16_t CLOSE_MIN[7] = {0, 1140, 1140, 1140, 1140, 1140, 780};
// ===================================================

#define PIN_SS    5
#define PIN_RST   27
#define PIN_LED   2
#define PIN_BOOT  0
#define MAX_ASSETS 40

MFRC522 mfrc(PIN_SS, PIN_RST);
MFRC522::MIFARE_Key keyA;
Preferences prefs;

struct TagData {
  char kind;
  uint8_t level;
  char id[9];
  uint8_t state;      // 0 en sitio, 1 prestado, 2 en revision
  uint16_t uses;
  uint32_t ts;
  char lastUser[9];
  uint16_t limitMin;
};

struct Asset {
  uint8_t used;
  char id[9];
  uint8_t level;
  uint8_t status;
  char holder[9];
  uint32_t ts;
  uint16_t uses;
  uint16_t limitMin;
  uint8_t alerted;
};

enum ReadRes { TAG_OK, TAG_AUTH, TAG_READ, TAG_BADMAC };

Asset assets[MAX_ASSETS];
bool seen[MAX_ASSETS];
bool invMode = false;
char incType = 0;
TagData curUser;
bool sessionActive = false;
unsigned long sessionUntil = 0;
unsigned long lastFlush = 0, lastOverdue = 0, lastCmd = 0;
bool wasConnected = false;
long pendCmdId = 0;            // id de la solicitud de alta remota en curso
unsigned long pendSince = 0;
int evLimit = 0;               // limite (min) que se adjunta al evento "prestamo"
struct { bool active; char kind; uint8_t level; char id[9]; uint16_t limit; } pend = {false, 0, 0, "", 0};

// ---------- LEDs ----------
void ledOk() {
  digitalWrite(PIN_LED, HIGH);
#if USE_EXT_LEDS
  digitalWrite(PIN_LED_OK, HIGH);
#endif
  delay(300);
  digitalWrite(PIN_LED, LOW);
#if USE_EXT_LEDS
  digitalWrite(PIN_LED_OK, LOW);
#endif
}

void ledErr() {
  for (int i = 0; i < 3; i++) {
    digitalWrite(PIN_LED, HIGH);
#if USE_EXT_LEDS
    digitalWrite(PIN_LED_ERR, HIGH);
#endif
    delay(100);
    digitalWrite(PIN_LED, LOW);
#if USE_EXT_LEDS
    digitalWrite(PIN_LED_ERR, LOW);
#endif
    delay(100);
  }
}

// ---------- Utilidades ----------
void trimId(const char* in, char* out) {
  int n = 0;
  for (int i = 0; i < 8 && in[i]; i++) if (in[i] != ' ') out[n++] = in[i];
  out[n] = 0;
}

void setId(char* dst, const char* src) {
  memset(dst, ' ', 8);
  dst[8] = 0;
  for (int i = 0; i < 8 && src[i]; i++) dst[i] = src[i];
}

bool timeOk() { return time(nullptr) > 1700000000; }
uint32_t nowEpoch() { return timeOk() ? (uint32_t)time(nullptr) : 0; }

bool inSchedule() {
  if (!timeOk()) return false;
  time_t t = time(nullptr);
  struct tm tmv;
  localtime_r(&t, &tmv);
  int m = tmv.tm_hour * 60 + tmv.tm_min;
  return m >= OPEN_MIN[tmv.tm_wday] && m < CLOSE_MIN[tmv.tm_wday];
}

// ---------- Registro en flash ----------
void saveRegistry() {
  prefs.begin("lab", false);
  prefs.putBytes("assets", assets, sizeof(assets));
  prefs.end();
}

void loadRegistry() {
  prefs.begin("lab", false);
  size_t n = prefs.getBytesLength("assets");
  if (n == sizeof(assets)) prefs.getBytes("assets", assets, sizeof(assets));
  else memset(assets, 0, sizeof(assets));
  prefs.end();
}

int findAsset(const char* id) {
  for (int i = 0; i < MAX_ASSETS; i++)
    if (assets[i].used && strncmp(assets[i].id, id, 8) == 0) return i;
  return -1;
}

int freeSlot() {
  for (int i = 0; i < MAX_ASSETS; i++) if (!assets[i].used) return i;
  return -1;
}

bool isOverdue(const Asset& a) {
  if (a.status != 1 || !timeOk() || a.ts == 0) return false;
  return ((uint32_t)time(nullptr) - a.ts) > (uint32_t)a.limitMin * 60UL;
}

int countOverdue(const char* userId) {
  int n = 0;
  for (int i = 0; i < MAX_ASSETS; i++)
    if (assets[i].used && isOverdue(assets[i]) && strncmp(assets[i].holder, userId, 8) == 0) n++;
  return n;
}

// ---------- Nube (Supabase) ----------
bool cloudOn() { return strstr(SUPA_URL, "TU_PROYECTO") == NULL; }

#define QN 16
char evq[QN][300];
int qh = 0, qc = 0;

void queueEvent(const char* type, const char* user, const char* asset, int level) {
  char u[9], a[9];
  trimId(user, u);
  trimId(asset, a);
  Serial.printf("[EVENTO] %s user=%s equipo=%s\n", type, u, a);
  if (!cloudOn()) return;
  if (qc == QN) { qh = (qh + 1) % QN; qc--; }   // cola llena: descarta el mas viejo
  int slot = (qh + qc) % QN;
  snprintf(evq[slot], sizeof(evq[slot]),
           "{\"device\":\"%s\",\"type\":\"%s\",\"user_id\":\"%s\",\"asset_id\":\"%s\",\"level\":%d,\"device_ts\":%lu,\"limit_min\":%d}",
           DEVICE_ID, type, u, a, level, (unsigned long)nowEpoch(), evLimit);
  qc++;
}

void flushQueue() {
  if (!cloudOn() || qc == 0 || WiFi.status() != WL_CONNECTED) return;
  WiFiClientSecure client;
  client.setInsecure();   // prototipo: sin validar certificado
  HTTPClient http;
  http.setTimeout(3000);
  String url = String(SUPA_URL) + "/rest/v1/events";
  if (!http.begin(client, url)) return;
  http.addHeader("Content-Type", "application/json");
  http.addHeader("apikey", SUPA_KEY);
  http.addHeader("Authorization", String("Bearer ") + SUPA_KEY);
  http.addHeader("Prefer", "return=minimal");
  int code = http.POST((uint8_t*)evq[qh], strlen(evq[qh]));
  http.end();
  if (code >= 200 && code < 300) {
    qh = (qh + 1) % QN; qc--;
  } else if (code >= 400 && code < 500) {
    Serial.printf("[NUBE] Rechazado (HTTP %d). Revise tabla/politicas. Evento descartado.\n", code);
    qh = (qh + 1) % QN; qc--;
  }
  // codigo < 0 o 5xx: sin red o servidor caido -> se reintenta
}

void alertMsg(const char* msg) {
  Serial.printf("[ALERTA] %s\n", msg);
}

// ---------- Comandos desde la web (tabla "commands") ----------
void cmdReport(long id, const char* st) {
  if (id <= 0 || WiFi.status() != WL_CONNECTED) return;
  WiFiClientSecure client;
  client.setInsecure();
  HTTPClient http;
  http.setTimeout(3000);
  String url = String(SUPA_URL) + "/rest/v1/commands?id=eq." + id;
  if (!http.begin(client, url)) return;
  http.addHeader("Content-Type", "application/json");
  http.addHeader("apikey", SUPA_KEY);
  http.addHeader("Authorization", String("Bearer ") + SUPA_KEY);
  http.PATCH(String("{\"status\":\"") + st + "\"}");
  http.end();
}

// Lee un valor de un JSON simple: "clave":"texto"  o  "clave":123
String jGet(const String& s, const char* key) {
  String k = String("\"") + key + "\":";
  int i = s.indexOf(k);
  if (i < 0) return "";
  i += k.length();
  if (s[i] == '"') {
    int j = s.indexOf('"', i + 1);
    if (j < 0) return "";
    return s.substring(i + 1, j);
  }
  int j = i;
  while (j < (int)s.length() && s[j] != ',' && s[j] != '}') j++;
  return s.substring(i, j);
}

// Alta remota: busca una solicitud pendiente (U = tarjeta, A = equipo)
void pollCommands() {
  if (!cloudOn() || pend.active || invMode || WiFi.status() != WL_CONNECTED) return;
  WiFiClientSecure client;
  client.setInsecure();
  HTTPClient http;
  http.setTimeout(3000);
  String url = String(SUPA_URL) + "/rest/v1/commands?status=eq.pending&kind=in.(U,A)&order=id.asc&limit=1";
  if (!http.begin(client, url)) return;
  http.addHeader("apikey", SUPA_KEY);
  http.addHeader("Authorization", String("Bearer ") + SUPA_KEY);
  int code = http.GET();
  String body = (code == 200) ? http.getString() : "";
  http.end();
  if (body.length() < 10) return;

  long id = jGet(body, "id").toInt();
  String kind = jGet(body, "kind"), ext = jGet(body, "ext_id");
  int lv = jGet(body, "level").toInt(), lim = jGet(body, "limit_min").toInt();
  if (id <= 0) return;
  if ((kind != "U" && kind != "A") || lv < 1 || lv > 4 || ext.length() < 1 || ext.length() > 8) {
    cmdReport(id, "error");
    return;
  }
  pend.active = true;
  pend.kind = kind[0];
  pend.level = lv;
  pend.limit = (kind == "A") ? (lim > 0 ? lim : DEFAULT_LIMIT_MIN) : 0;
  strncpy(pend.id, ext.c_str(), 8);
  pend.id[8] = 0;
  pendCmdId = id;
  pendSince = millis();
  Serial.printf(">> ALTA REMOTA: acerque una tarjeta/etiqueta EN BLANCO para grabar %c nivel %d ID %s (60 s)\n",
                pend.kind, lv, pend.id);
}

// Autorizacion de prestamo hecha en la ventana flotante del panel.
// Devuelve: -1 sin red, 0 sin autorizacion, >0 minutos autorizados.
int webAuthLimit(const char* userId, long* cid) {
  *cid = 0;
  if (!cloudOn() || WiFi.status() != WL_CONNECTED) return -1;
  char u[9];
  trimId(userId, u);
  WiFiClientSecure client;
  client.setInsecure();
  HTTPClient http;
  http.setTimeout(3000);
  String url = String(SUPA_URL) + "/rest/v1/commands?kind=eq.L&status=eq.pending&ext_id=eq." + u + "&order=id.desc&limit=1";
  if (!http.begin(client, url)) return -1;
  http.addHeader("apikey", SUPA_KEY);
  http.addHeader("Authorization", String("Bearer ") + SUPA_KEY);
  int code = http.GET();
  String body = (code == 200) ? http.getString() : "";
  http.end();
  if (code != 200) return -1;
  if (body.length() < 10) return 0;
  *cid = jGet(body, "id").toInt();
  return jGet(body, "limit_min").toInt();
}

// ---------- Formato de etiqueta (sector 1: bloques 4,5,6; el 7 NUNCA se toca) ----------
void packBlocks(const TagData& t, uint8_t* b4, uint8_t* b5) {
  memset(b4, 0, 16); memset(b5, 0, 16);
  b4[0] = t.kind; b4[1] = t.level; memcpy(b4 + 2, t.id, 8);
  b4[10] = t.limitMin >> 8; b4[11] = t.limitMin & 0xFF;
  b5[0] = t.state;
  b5[1] = t.uses >> 8; b5[2] = t.uses & 0xFF;
  b5[3] = t.ts >> 24; b5[4] = t.ts >> 16; b5[5] = t.ts >> 8; b5[6] = t.ts;
  memcpy(b5 + 7, t.lastUser, 8);
}

void unpackBlocks(TagData& t, const uint8_t* b4, const uint8_t* b5) {
  t.kind = b4[0]; t.level = b4[1];
  memcpy(t.id, b4 + 2, 8); t.id[8] = 0;
  t.limitMin = ((uint16_t)b4[10] << 8) | b4[11];
  t.state = b5[0];
  t.uses = ((uint16_t)b5[1] << 8) | b5[2];
  t.ts = ((uint32_t)b5[3] << 24) | ((uint32_t)b5[4] << 16) | ((uint32_t)b5[5] << 8) | b5[6];
  memcpy(t.lastUser, b5 + 7, 8); t.lastUser[8] = 0;
}

bool computeMac(const uint8_t* b4, const uint8_t* b5, uint8_t* out16) {
  uint8_t msg[16 + 16 + 10];
  memcpy(msg, b4, 16);
  memcpy(msg + 16, b5, 16);
  memcpy(msg + 32, mfrc.uid.uidByte, mfrc.uid.size);
  size_t len = 32 + mfrc.uid.size;
  uint8_t full[32];
  const mbedtls_md_info_t* info = mbedtls_md_info_from_type(MBEDTLS_MD_SHA256);
  if (mbedtls_md_hmac(info, HMAC_KEY, sizeof(HMAC_KEY), msg, len, full) != 0) return false;
  memcpy(out16, full, 16);
  return true;
}

bool authSector() {
  return mfrc.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 7, &keyA, &(mfrc.uid)) == MFRC522::STATUS_OK;
}

bool readBlock(byte block, uint8_t* out16) {
  byte buf[18]; byte sz = sizeof(buf);
  if (mfrc.MIFARE_Read(block, buf, &sz) != MFRC522::STATUS_OK) return false;
  memcpy(out16, buf, 16);
  return true;
}

bool writeBlock(byte block, uint8_t* data16) {
  return mfrc.MIFARE_Write(block, data16, 16) == MFRC522::STATUS_OK;
}

ReadRes loadTag(TagData& t) {
  if (!authSector()) return TAG_AUTH;
  uint8_t b4[16], b5[16], b6[16], mac[16];
  if (!readBlock(4, b4) || !readBlock(5, b5) || !readBlock(6, b6)) return TAG_READ;
  if (!computeMac(b4, b5, mac)) return TAG_READ;
  if (memcmp(mac, b6, 16) != 0) return TAG_BADMAC;
  unpackBlocks(t, b4, b5);
  if (t.kind != 'U' && t.kind != 'A') return TAG_BADMAC;
  return TAG_OK;
}

bool saveTag(const TagData& t) {
  if (!authSector()) return false;
  uint8_t b4[16], b5[16], mac[16];
  packBlocks(t, b4, b5);
  if (!computeMac(b4, b5, mac)) return false;
  return writeBlock(4, b4) && writeBlock(5, b5) && writeBlock(6, mac);
}

// ---------- Logica ----------
void provisionCard() {
  TagData t;
  memset(&t, 0, sizeof(t));
  t.kind = pend.kind; t.level = pend.level;
  setId(t.id, pend.id);
  setId(t.lastUser, "");
  t.limitMin = (pend.kind == 'A') ? pend.limit : 0;
  if (!saveTag(t)) {
    Serial.println("Error al grabar. Reintente.");
    if (pendCmdId) { cmdReport(pendCmdId, "error"); pendCmdId = 0; }
    ledErr();
    pend.active = false;
    return;
  }
  if (t.kind == 'A') {
    int i = findAsset(t.id);
    if (i < 0) i = freeSlot();
    if (i < 0) {
      Serial.println("AVISO: registro lleno (40 equipos). Etiqueta grabada pero sin registrar.");
    } else {
      Asset& a = assets[i];
      memset(&a, 0, sizeof(a));
      a.used = 1;
      memcpy(a.id, t.id, 9);
      a.level = t.level;
      a.status = 0;
      setId(a.holder, "");
      a.limitMin = t.limitMin;
      saveRegistry();
    }
  }
  Serial.printf(">> ALTA correcta: %s %s nivel %d\n", t.kind == 'U' ? "USUARIO" : "ACTIVO", pend.id, t.level);
  queueEvent(t.kind == 'U' ? "alta_usuario" : "alta_activo", t.kind == 'U' ? t.id : "", t.kind == 'A' ? t.id : "", t.level);
  pend.active = false;
  if (pendCmdId) { cmdReport(pendCmdId, "done"); pendCmdId = 0; }
  ledOk();
}

void registerIncident(TagData& t, int idx, char type) {
  Asset& a = assets[idx];
  t.state = 2;
  t.ts = nowEpoch();
  if (!saveTag(t)) { Serial.println("Error al grabar la etiqueta. Reintente."); ledErr(); return; }
  a.status = 2; a.ts = t.ts; a.alerted = 1;
  saveRegistry();
  const char* who = sessionActive ? curUser.id : a.holder;
  char w[9], id[9], m[120];
  trimId(who, w); trimId(t.id, id);
  Serial.printf(">> INCIDENCIA (%s) en %s. Equipo en REVISION.\n", type == 'I' ? "incompleto" : "danado", id);
  queueEvent(type == 'I' ? "incidencia_incompleto" : "incidencia_danado", who, t.id, t.level);
  snprintf(m, sizeof(m), "INCIDENCIA %s: equipo %s, usuario %s", type == 'I' ? "incompleto" : "danado", id, w);
  alertMsg(m);
  ledOk();
}

void handleUser(TagData& t) {
  char u[9];
  trimId(t.id, u);
  if (t.level < ADMIN_LEVEL) {
    if (!timeOk()) { Serial.println("Sin hora (WiFi/NTP). No se puede verificar el horario."); ledErr(); return; }
    if (!inSchedule()) {
      Serial.printf("FUERA DE HORARIO: acceso denegado a %s\n", u);
      queueEvent("fuera_horario", t.id, "", t.level);
      ledErr();
      return;
    }
  }
  curUser = t;
  sessionActive = true;
  sessionUntil = millis() + SESSION_MS;
  Serial.printf("Hola %s (nivel %d). Autorice el prestamo en la web y acerque el equipo.\n", u, t.level);
  int od = countOverdue(t.id);
  if (od > 0) Serial.printf("AVISO: tiene %d prestamo(s) VENCIDO(S). Nuevos prestamos bloqueados hasta devolver.\n", od);
  queueEvent("login", t.id, "", t.level);
  ledOk();
}

void handleAsset(TagData& t) {
  char aid[9];
  trimId(t.id, aid);

  int idx = findAsset(t.id);
  if (idx < 0) {   // etiqueta valida pero no registrada en este ESP32: se adopta
    idx = freeSlot();
    if (idx < 0) { Serial.println("Registro lleno (40 equipos)."); ledErr(); return; }
    Asset& n = assets[idx];
    memset(&n, 0, sizeof(n));
    n.used = 1;
    memcpy(n.id, t.id, 9);
    n.level = t.level; n.status = t.state;
    memcpy(n.holder, t.lastUser, 9);
    n.ts = t.ts; n.uses = t.uses;
    n.limitMin = t.limitMin ? t.limitMin : DEFAULT_LIMIT_MIN;
    saveRegistry();
    Serial.printf("Equipo %s agregado al registro.\n", aid);
  }
  Asset& a = assets[idx];

  // Coherencia etiqueta <-> registro (detecta etiquetas restauradas/clonadas)
  if (a.uses != t.uses || a.status != t.state) {
    char m[100];
    Serial.printf("!! INCONSISTENCIA en %s: la etiqueta no coincide con el registro.\n", aid);
    queueEvent("inconsistencia", "", t.id, t.level);
    snprintf(m, sizeof(m), "INCONSISTENCIA: etiqueta %s no coincide con el registro (posible copia)", aid);
    alertMsg(m);
    ledErr();
    return;
  }

  if (incType) {
    registerIncident(t, idx, incType);
    incType = 0;
    return;
  }

  if (a.status == 2) {   // en revision
    if (sessionActive && curUser.level >= ADMIN_LEVEL) {
      t.state = 0; t.ts = nowEpoch();
      if (saveTag(t)) {
        a.status = 0; a.ts = t.ts; saveRegistry();
        Serial.printf(">> %s revisado y HABILITADO por administrador.\n", aid);
        queueEvent("incidencia_resuelta", curUser.id, t.id, t.level);
        ledOk();
      } else { Serial.println("Error al grabar. Reintente."); ledErr(); }
    } else {
      Serial.printf("%s esta EN REVISION por incidencia. Solo un administrador puede habilitarlo.\n", aid);
      ledErr();
    }
    return;
  }

  if (a.status == 1) {   // prestado -> devolucion
    bool admin = sessionActive && curUser.level >= ADMIN_LEVEL;
    bool holder = sessionActive && strncmp(curUser.id, a.holder, 8) == 0;
    if (sessionActive && !admin && !holder) {
      char h[9];
      trimId(a.holder, h);
      Serial.printf("%s ya esta EN USO por %s. No se puede prestar a otra persona.\n", aid, h);
      queueEvent("reserva_bloqueada", curUser.id, t.id, t.level);
      ledErr();
      return;
    }
    if (digitalRead(PIN_BOOT) == LOW) {   // BOOT presionado = devolucion con danio
      registerIncident(t, idx, 'D');
      return;
    }
    uint32_t prev = a.ts;
    t.state = 0; t.ts = nowEpoch();
    if (!saveTag(t)) { Serial.println("Error al grabar. Reintente."); ledErr(); return; }
    a.status = 0; a.ts = t.ts; a.alerted = 0;
    saveRegistry();
    char h[9];
    trimId(a.holder, h);
    if (prev && t.ts) Serial.printf(">> DEVUELTO %s (de %s) tras %lu min\n", aid, h, (unsigned long)((t.ts - prev) / 60));
    else Serial.printf(">> DEVUELTO %s (de %s)\n", aid, h);
    queueEvent("devolucion", a.holder, t.id, t.level);
    ledOk();
    return;
  }

  // ----- status 0: PRESTAMO -----
  if (!sessionActive) { Serial.println("Primero acerque su tarjeta de usuario."); ledErr(); return; }
  if (!timeOk()) { Serial.println("Sin hora (WiFi/NTP). No se pueden registrar prestamos."); ledErr(); return; }
  if (curUser.level < ADMIN_LEVEL && !inSchedule()) {
    Serial.println("FUERA DE HORARIO.");
    queueEvent("fuera_horario", curUser.id, t.id, t.level);
    ledErr();
    return;
  }
  if (curUser.level < a.level) {
    Serial.printf("ACCESO DENEGADO: %s requiere nivel %d\n", aid, a.level);
    queueEvent("acceso_denegado", curUser.id, t.id, t.level);
    ledErr();
    return;
  }
  if (BLOCK_ON_OVERDUE && countOverdue(curUser.id) > 0) {
    Serial.println("PRESTAMO BLOQUEADO: tiene devoluciones vencidas pendientes.");
    queueEvent("bloqueo_pendientes", curUser.id, t.id, t.level);
    ledErr();
    return;
  }

  // Autorizacion y tiempo del prestamo hechos en la ventana flotante del panel
  long cid = 0;
  int lim = webAuthLimit(curUser.id, &cid);
  if (REQUIRE_WEB_CONFIRM && lim == 0) {
    Serial.println("Falta CONFIRMAR el prestamo en la web (tiempo y autorizacion).");
    queueEvent("sin_confirmar", curUser.id, t.id, t.level);
    ledErr();
    return;
  }
  if (lim > 0) t.limitMin = lim;

  t.state = 1; t.uses++; t.ts = nowEpoch();
  memcpy(t.lastUser, curUser.id, 9);
  if (!saveTag(t)) { Serial.println("Error al grabar. Reintente."); ledErr(); return; }
  a.status = 1; a.uses = t.uses; a.ts = t.ts; a.alerted = 0;
  memcpy(a.holder, curUser.id, 9);
  if (lim > 0) a.limitMin = lim;
  saveRegistry();
  if (lim > 0) cmdReport(cid, "done");

  char u[9];
  trimId(curUser.id, u);
  Serial.printf(">> PRESTADO %s a %s. Limite: %u min\n", aid, u, (unsigned)a.limitMin);
  evLimit = a.limitMin;
  queueEvent("prestamo", curUser.id, t.id, t.level);
  evLimit = 0;
  if (t.uses >= MAX_USES) {
    char m[100];
    snprintf(m, sizeof(m), "MANTENIMIENTO: equipo %s llego a %u usos", aid, (unsigned)t.uses);
    queueEvent("mantenimiento", curUser.id, t.id, t.level);
    alertMsg(m);
  }
  sessionUntil = millis() + SESSION_MS;   // permite llevar varios equipos
  ledOk();
}

// ---------- Inventario ----------
void invStart() {
  invMode = true;
  memset(seen, 0, sizeof(seen));
  Serial.println(">> INVENTARIO iniciado. Pase cada equipo por el lector. Escriba FIN al terminar.");
}

void invFinish() {
  invMode = false;
  int total = 0, det = 0, falt = 0;
  for (int i = 0; i < MAX_ASSETS; i++) {
    if (!assets[i].used) continue;
    total++;
    char id[9], h[9];
    trimId(assets[i].id, id);
    trimId(assets[i].holder, h);
    if (seen[i]) det++;
    if (assets[i].status == 0 && !seen[i]) {
      falt++;
      Serial.printf("  FALTANTE: %s\n", id);
      queueEvent("faltante", "", assets[i].id, assets[i].level);
    } else if (assets[i].status == 1) {
      Serial.printf("  prestado: %s -> %s%s\n", id, h, seen[i] ? " (ATENCION: detectado en el inventario)" : "");
    } else if (assets[i].status == 2) {
      Serial.printf("  en revision: %s\n", id);
    }
  }
  Serial.printf(">> Registrados: %d | Detectados: %d | Faltantes: %d\n", total, det, falt);
  if (falt > 0) {
    char m[100];
    snprintf(m, sizeof(m), "INVENTARIO: %d equipo(s) faltante(s) de %d registrados", falt, total);
    alertMsg(m);
  }
}

void listAssets() {
  Serial.println("--- REGISTRO DE EQUIPOS ---");
  for (int i = 0; i < MAX_ASSETS; i++) {
    if (!assets[i].used) continue;
    char id[9], h[9];
    trimId(assets[i].id, id);
    trimId(assets[i].holder, h);
    const char* st = assets[i].status == 0 ? "en sitio" : assets[i].status == 1 ? "PRESTADO" : "EN REVISION";
    Serial.printf("%-8s nivel %d | %-11s | titular: %-8s | usos %u | limite %u min%s\n",
                  id, assets[i].level, st, h, (unsigned)assets[i].uses, (unsigned)assets[i].limitMin,
                  isOverdue(assets[i]) ? " | VENCIDO" : "");
  }
  Serial.println("---------------------------");
}

void checkOverdue() {
  if (!timeOk()) return;
  for (int i = 0; i < MAX_ASSETS; i++) {
    if (assets[i].used && !assets[i].alerted && isOverdue(assets[i])) {
      assets[i].alerted = 1;
      saveRegistry();
      char id[9], h[9], m[120];
      trimId(assets[i].id, id);
      trimId(assets[i].holder, h);
      snprintf(m, sizeof(m), "VENCIDO: equipo %s con %s excedio %u min", id, h, (unsigned)assets[i].limitMin);
      queueEvent("vencido", assets[i].holder, assets[i].id, assets[i].level);
      alertMsg(m);
    }
  }
}

// ---------- Comandos Serial ----------
void printHelp() {
  Serial.println("Comandos: U 2 JUAN0001 | A 3 OSC00001 120 | INV | FIN | INC D | INC I | LIST | HORA | HELP");
}

void handleSerial() {
  if (!Serial.available()) return;
  String line = Serial.readStringUntil('\n');
  line.trim();
  line.toUpperCase();
  if (line.length() == 0) return;

  if (line == "INV")  { invStart(); return; }
  if (line == "FIN")  { invFinish(); return; }
  if (line == "LIST") { listAssets(); return; }
  if (line == "HELP") { printHelp(); return; }
  if (line == "HORA") {
    if (!timeOk()) { Serial.println("Hora no sincronizada (revise WiFi)."); return; }
    time_t t = time(nullptr);
    struct tm tmv;
    localtime_r(&t, &tmv);
    Serial.printf("Hora local: %02d:%02d:%02d (dia %d, horario %s)\n", tmv.tm_hour, tmv.tm_min, tmv.tm_sec,
                  tmv.tm_wday, inSchedule() ? "AUTORIZADO" : "CERRADO");
    return;
  }
  if (line.startsWith("INC ")) {
    char ty = line.charAt(4);
    if (ty == 'D' || ty == 'I') {
      incType = ty;
      Serial.println(">> Acerque el equipo para registrar la incidencia.");
      return;
    }
  }

  char k; int lv; char id[16]; int lim = DEFAULT_LIMIT_MIN;
  int n = sscanf(line.c_str(), "%c %d %15s %d", &k, &lv, id, &lim);
  if (n >= 3 && (k == 'U' || k == 'A') && lv >= 1 && lv <= 4 && lim > 0 && lim <= 65000) {
    char clean[9]; int c = 0;
    for (int i = 0; id[i] && c < 8; i++) if (isalnum((unsigned char)id[i])) clean[c++] = id[i];
    clean[c] = 0;
    if (c > 0) {
      if (pendCmdId) { cmdReport(pendCmdId, "expired"); pendCmdId = 0; }   // el comando serial reemplaza al remoto
      pend.active = true; pend.kind = k; pend.level = lv; pend.limit = lim;
      strcpy(pend.id, clean);
      Serial.printf(">> Acerque la tarjeta/etiqueta para grabar %c nivel %d ID %s\n", k, lv, clean);
      return;
    }
  }
  printHelp();
}

void handleCard() {
  if (pend.active) { provisionCard(); return; }

  TagData t;
  ReadRes r = loadTag(t);
  if (r != TAG_OK) {
    if (r == TAG_BADMAC) {
      Serial.println("ETIQUETA INVALIDA: alterada, copiada o sin alta.");
      queueEvent("tag_invalido", "", "", 0);
      alertMsg("Etiqueta invalida o alterada detectada");
    } else {
      Serial.println("Error de lectura. Mantenga la etiqueta quieta y reintente.");
    }
    ledErr();
    return;
  }

  if (invMode) {
    if (t.kind != 'A') { Serial.println("Inventario: solo se aceptan equipos."); return; }
    int i = findAsset(t.id);
    char id[9];
    trimId(t.id, id);
    if (i < 0) { Serial.printf("Inventario: %s NO esta registrado.\n", id); ledErr(); return; }
    seen[i] = true;
    Serial.printf("Inventario: detectado %s\n", id);
    ledOk();
    return;
  }

  if (t.kind == 'U') handleUser(t);
  else handleAsset(t);
}

void setup() {
  Serial.begin(115200);
  delay(300);
  pinMode(PIN_LED, OUTPUT);
  pinMode(PIN_BOOT, INPUT_PULLUP);
#if USE_EXT_LEDS
  pinMode(PIN_LED_OK, OUTPUT);
  pinMode(PIN_LED_ERR, OUTPUT);
#endif

  SPI.begin(18, 19, 23, PIN_SS);
  mfrc.PCD_Init();
  for (byte i = 0; i < 6; i++) keyA.keyByte[i] = 0xFF;
  byte v = mfrc.PCD_ReadRegister(MFRC522::VersionReg);
  Serial.printf("RC522 version: 0x%02X %s\n", v, (v == 0x00 || v == 0xFF) ? "-> ERROR: revise el cableado" : "-> OK");

  loadRegistry();
  WiFi.mode(WIFI_STA);
  WiFi.setAutoReconnect(true);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  configTime(GMT_OFFSET_SEC, 0, "pool.ntp.org");

  Serial.printf("Nube: %s\n", cloudOn() ? "ACTIVADA (Supabase)" : "desactivada");
  Serial.printf("Confirmacion de prestamo en la web: %s\n", REQUIRE_WEB_CONFIRM ? "OBLIGATORIA" : "opcional");
  Serial.println("Sistema listo.");
  printHelp();
}

void loop() {
  handleSerial();

  bool conn = (WiFi.status() == WL_CONNECTED);
  if (conn != wasConnected) {
    wasConnected = conn;
    if (conn) Serial.printf("WiFi conectado. IP: %s\n", WiFi.localIP().toString().c_str());
    else Serial.println("WiFi desconectado (se reintenta solo).");
  }

  if (sessionActive && millis() > sessionUntil) {
    sessionActive = false;
    Serial.println("Sesion cerrada.");
  }

  // Alta remota: vence a los 60 s si no se acerca ninguna tarjeta
  if (pend.active && pendCmdId && millis() - pendSince > 60000) {
    pend.active = false;
    cmdReport(pendCmdId, "expired");
    pendCmdId = 0;
    Serial.println("Alta remota expirada.");
  }

  if (millis() - lastFlush > 2000) { lastFlush = millis(); flushQueue(); }
  if (millis() - lastCmd > 4000)   { lastCmd = millis();   pollCommands(); }
  if (millis() - lastOverdue > 30000) { lastOverdue = millis(); checkOverdue(); }

  if (!mfrc.PICC_IsNewCardPresent() || !mfrc.PICC_ReadCardSerial()) return;

  handleCard();

  mfrc.PICC_HaltA();
  mfrc.PCD_StopCrypto1();
  delay(500);
}
